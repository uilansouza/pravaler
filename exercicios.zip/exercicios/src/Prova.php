<?php

namespace App;

class Prova
{

    public function QuestaoUm(int $n, array $arr)
    {

    }

    public function QuestaoDois(int $n)
    {

    }

    public function QuestaoTres(string $s)
    {

    }

    public function QuestaoQuatro(int $n, array $a, array $b, array $v)
    {

    }
}
